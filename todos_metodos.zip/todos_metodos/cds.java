public class cds {
    public static todos Todos = new todos();
    public static void cds() {
        
        todos.CalcularDouble=todos.numero1D*1.024;
        todos.CalcularDouble2=(int)((todos.numero1D / 700)+1);

        System.out.println("CDs: "+todos.CalcularDouble2);


    }
}
