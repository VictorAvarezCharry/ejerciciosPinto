public class promedio_two {

    public static todos Todos = new todos();

    public static void Promedio_two(){
        
        todos.calcularInt=(todos.numero1+todos.numero2);
        System.out.println("Promedio: "+ todos.calcularInt/2);
    }
}
