
public class par {
    public static todos Todos = new todos();
    public static void diezPares() {

        for(todos.contador = 1; todos.numero1 <= 9; todos.contador++) {
            todos.numero1 = todos.numero1 + 2;
            System.out.println("Los primeros 10 numeros pares son: "+todos.numero1);
            
        }
        
    }
}
