public class Distancia {

    public static todos Todos = new todos();

    public static void distancia(){

        Todos.calcularInt = Todos.numero1*Todos.numero2;

        System.out.println("La distancia es: "+todos.calcularInt);

    }

}
