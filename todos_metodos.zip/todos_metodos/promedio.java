public class promedio {
    public static void promedio_three() {

        todos.calcularInt=(todos.numero1 + todos.numero2 + todos.numero3)/3;

        System.out.println("La nota final es: "+todos.calcularInt);

    }
}
