public class romanos {
    public static todos Todos = new todos();
    public static void romanos() {
        
        switch (todos.numero1){
            case 1:{
                todos.numero1=1;
                System.out.println("equivalente a numero romano es: I");
                break;
            }
            case 2:{
                todos.numero1=2;
                System.out.println("equivalente a numero romano es: II");
                break;
            }
            case 3:{
                todos.numero1=3;
                System.out.println("equivalente a numero romano es: III");
                break;
            }
            case 4:{
                todos.numero1=4;
                System.out.println("equivalente a numero romano es: IV");
                break;
            }
            case 5:{
                todos.numero1=5;
                System.out.println("equivalente a numero romano es: V");
                break;
            }
            case 6:{
                todos.numero1=6;
                System.out.println("equivalente a numero romano es: VI");
                break;
            }
            case 7:{
                todos.numero1=7;
                System.out.println("equivalente a numero romano es: VII");
                break;
            }
            case 8:{
                todos.numero1=8;
                System.out.println("equivalente a numero romano es: VIII");
                break;
            }
            case 9:{
                todos.numero1=9;
                System.out.println("equivalente a numero romano es: IX");
                break;
            }
                case 10:{
                todos.numero1=10;
                System.out.println("equivalente a numero romano es: X");
            break;
            }       
        }
    }
}
